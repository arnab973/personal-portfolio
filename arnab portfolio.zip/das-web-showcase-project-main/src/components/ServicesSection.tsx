
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Briefcase, Mail, Search } from 'lucide-react';

const ServicesSection = () => {
  const services = [
    {
      title: 'Interactive Resume Design',
      description: 'Creating modern, interactive resumes that stand out in the digital landscape with engaging animations and responsive layouts.',
      icon: FileText,
      color: 'from-purple-500 to-blue-500',
      bgColor: 'from-purple-50 to-blue-50'
    },
    {
      title: 'Personal Portfolio Development',
      description: 'Building stunning portfolio websites that showcase your skills and projects effectively with modern design principles.',
      icon: Briefcase,
      color: 'from-blue-500 to-teal-500',
      bgColor: 'from-blue-50 to-teal-50'
    },
    {
      title: 'Contact Form Integration',
      description: 'Implementing contact forms with email notification systems for seamless communication and lead generation.',
      icon: Mail,
      color: 'from-teal-500 to-green-500',
      bgColor: 'from-teal-50 to-green-50'
    },
    {
      title: 'SEO Optimization',
      description: 'Optimizing websites for search engines to improve web visibility and ranking with modern SEO techniques.',
      icon: Search,
      color: 'from-green-500 to-purple-500',
      bgColor: 'from-green-50 to-purple-50'
    }
  ];

  return (
    <section id="services" className="py-24 bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-portfolio-purple/5 to-portfolio-blue/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-br from-portfolio-orange/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm mb-6">
            <span className="text-sm font-medium text-gray-700">What I offer</span>
          </div>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple to-portfolio-orange">Services</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-portfolio-purple to-portfolio-orange mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive web development services tailored to your needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="group text-center hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 bg-white/70 backdrop-blur-sm border-0 overflow-hidden">
              <CardContent className="p-8 relative">
                {/* Background gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.bgColor} opacity-0 group-hover:opacity-50 transition-opacity duration-300`}></div>
                
                <div className="relative z-10">
                  <div className={`w-20 h-20 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
                    <service.icon className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-portfolio-purple transition-colors duration-300">{service.title}</h3>
                  <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">{service.description}</p>
                </div>
                
                {/* Hover border effect */}
                <div className={`absolute inset-0 border-2 border-transparent group-hover:border-gradient-to-r ${service.color} rounded-lg transition-all duration-300`}></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
