
import { Heart, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white py-16 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-portfolio-purple/10 to-portfolio-blue/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-gradient-to-br from-portfolio-orange/10 to-portfolio-purple/10 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-6">
            <h3 className="text-3xl font-bold">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple via-portfolio-blue to-portfolio-orange">
                Arnab Das
              </span>
            </h3>
            <p className="text-gray-300 leading-relaxed text-lg">
              Full Stack Developer passionate about creating innovative web solutions and bringing ideas to life through code.
            </p>
            <div className="flex space-x-2">
              <div className="w-2 h-2 bg-portfolio-purple rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-portfolio-blue rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
              <div className="w-2 h-2 bg-portfolio-orange rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-xl font-bold text-white mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'About', 'Skills', 'Projects', 'Services', 'Contact'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => {
                      const element = document.getElementById(item.toLowerCase());
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="text-gray-300 hover:text-white hover:translate-x-2 transition-all duration-300 text-lg group flex items-center"
                  >
                    <span className="w-2 h-2 bg-portfolio-orange rounded-full mr-3 group-hover:bg-portfolio-purple transition-colors duration-300"></span>
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-6">
            <h4 className="text-xl font-bold text-white mb-6">Subscribe To Get Latest Updates</h4>
            <p className="text-gray-300 mb-6 text-lg">Stay updated with my latest projects and blog posts.</p>
            <div className="space-y-4">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 bg-white/10 backdrop-blur-sm text-white rounded-l-xl border border-white/20 focus:outline-none focus:ring-2 focus:ring-portfolio-purple placeholder-gray-400"
                />
                <button className="bg-gradient-to-r from-portfolio-purple to-portfolio-blue px-6 py-3 rounded-r-xl font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-300 text-lg flex items-center">
              © 2024 Arnab Das. All rights reserved. | Built with 
              <Heart className="w-5 h-5 text-red-500 mx-2 animate-pulse" />
              using React & Tailwind CSS
            </p>
            
            <Button
              onClick={scrollToTop}
              className="bg-gradient-to-r from-portfolio-purple to-portfolio-blue hover:from-portfolio-purple/90 hover:to-portfolio-blue/90 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110"
            >
              <ArrowUp className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
