
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github, Eye } from 'lucide-react';

const ProjectsSection = () => {
  const projects = [
    {
      title: 'Facebook Login Page Clone',
      description: 'Built using HTML, CSS, and JavaScript as a UI/UX practice project replicating the Facebook login experience with modern design patterns.',
      technologies: ['HTML', 'CSS', 'JavaScript'],
      image: '/lovable-uploads/04a53ea1-9e53-431d-9871-fe2ebcb2f022.png',
      type: 'UI/UX Practice',
      gradient: 'from-blue-500 to-indigo-600'
    },
    {
      title: 'Canteen Web Page',
      description: 'A basic static web page created using HTML, CSS, and JavaScript to represent a university canteen\'s digital presence with responsive design.',
      technologies: ['HTML', 'CSS', 'JavaScript'],
      image: '/lovable-uploads/04a53ea1-9e53-431d-9871-fe2ebcb2f022.png',
      type: 'Static Website',
      gradient: 'from-green-500 to-teal-600'
    }
  ];

  return (
    <section id="projects" className="py-24 bg-gradient-to-br from-white via-gray-50 to-purple-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-portfolio-purple/5 to-portfolio-blue/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-gradient-to-br from-portfolio-orange/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm mb-6">
            <span className="text-sm font-medium text-gray-700">My creative work</span>
          </div>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple to-portfolio-orange">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-portfolio-purple to-portfolio-orange mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Digital Product Showcases
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {projects.map((project, index) => (
            <Card key={index} className="group overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 bg-white/70 backdrop-blur-sm border-0">
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {/* Overlay gradient */}
                <div className={`absolute inset-0 bg-gradient-to-r ${project.gradient} opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex items-center justify-center`}>
                  <div className="text-white text-center transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <Eye className="w-12 h-12 mx-auto mb-2" />
                    <p className="text-lg font-semibold">View Project</p>
                  </div>
                </div>
                <div className="absolute top-4 left-4">
                  <span className={`bg-gradient-to-r ${project.gradient} text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg backdrop-blur-sm`}>
                    {project.type}
                  </span>
                </div>
              </div>
              
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-portfolio-purple transition-colors duration-300">{project.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 px-4 py-2 rounded-full text-sm font-medium hover:from-portfolio-blue/10 hover:to-portfolio-purple/10 hover:text-portfolio-purple transition-all duration-300"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-4">
                  <Button
                    className="flex-1 bg-gradient-to-r from-portfolio-purple to-portfolio-blue text-white hover:from-portfolio-purple/90 hover:to-portfolio-blue/90 rounded-xl font-semibold py-3 group shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <ExternalLink className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                    Live Demo
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 border-2 border-gray-300 text-gray-700 hover:border-portfolio-blue hover:text-portfolio-blue rounded-xl font-semibold py-3 group transition-all duration-300"
                  >
                    <Github className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                    Source Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <Button className="bg-gradient-to-r from-portfolio-purple via-portfolio-blue to-portfolio-orange text-white px-10 py-4 rounded-2xl font-bold text-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
