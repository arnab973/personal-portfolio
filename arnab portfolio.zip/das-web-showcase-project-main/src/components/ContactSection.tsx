
import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Mail, Linkedin, Facebook, Instagram, Send, User, MessageSquare } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    toast({
      title: "Message Sent! 🚀",
      description: "Thank you for your message. I'll get back to you soon!",
    });
    
    setFormData({ name: '', email: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      type: 'Email',
      value: 'arnabcse2003@gmail.com',
      link: 'mailto:arnabcse2003@gmail.com',
      icon: Mail,
      color: 'from-red-500 to-pink-500',
      bgColor: 'from-red-50 to-pink-50'
    },
    {
      type: 'LinkedIn',
      value: 'linkedin.com/in/arnabdas2003',
      link: 'https://linkedin.com/in/arnabdas2003',
      icon: Linkedin,
      color: 'from-blue-600 to-blue-700',
      bgColor: 'from-blue-50 to-blue-100'
    },
    {
      type: 'Facebook',
      value: 'Facebook Profile',
      link: 'https://www.facebook.com/share/1HVP3gHHFY/',
      icon: Facebook,
      color: 'from-blue-500 to-indigo-600',
      bgColor: 'from-blue-50 to-indigo-50'
    },
    {
      type: 'Instagram',
      value: '@creative_arnab',
      link: 'https://www.instagram.com/creative_arnab?igsh=MWZmdmdvZTFvMGZ4Ng==',
      icon: Instagram,
      color: 'from-pink-500 to-purple-600',
      bgColor: 'from-pink-50 to-purple-50'
    }
  ];

  return (
    <section id="contact" className="py-24 bg-gradient-to-br from-white via-gray-50 to-blue-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-portfolio-blue/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-gradient-to-br from-portfolio-orange/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm mb-6">
            <span className="text-sm font-medium text-gray-700">Let's connect</span>
          </div>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Got A Project? Let's <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple to-portfolio-orange">Talk</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-portfolio-purple to-portfolio-orange mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ready to bring your ideas to life? Let's discuss your project and create something amazing together.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <Card className="shadow-2xl bg-white/70 backdrop-blur-sm border-0 overflow-hidden">
            <CardContent className="p-10">
              <div className="mb-8">
                <h3 className="text-3xl font-bold text-gray-900 mb-4 flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-portfolio-purple to-portfolio-blue rounded-xl flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  Send Me a Message
                </h3>
                <p className="text-gray-600">Fill out the form below and I'll get back to you as soon as possible.</p>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="pl-12 py-4 text-lg border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-portfolio-purple focus:border-transparent transition-all duration-300 bg-white/50 backdrop-blur-sm"
                  />
                </div>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="pl-12 py-4 text-lg border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-portfolio-purple focus:border-transparent transition-all duration-300 bg-white/50 backdrop-blur-sm"
                  />
                </div>
                <div className="relative">
                  <MessageSquare className="absolute left-3 top-4 text-gray-400 w-5 h-5" />
                  <Textarea
                    name="message"
                    placeholder="Your Message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="pl-12 pt-4 text-lg border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-portfolio-purple focus:border-transparent resize-none transition-all duration-300 bg-white/50 backdrop-blur-sm"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-portfolio-purple to-portfolio-blue text-white py-4 rounded-xl font-bold text-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 group"
                >
                  <Send className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform duration-300" />
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Get In Touch</h3>
              <p className="text-xl text-gray-600 mb-12 leading-relaxed">
                Feel free to reach out to me through any of the following platforms. I'm always excited to discuss new opportunities and collaborations.
              </p>
            </div>

            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <Card key={index} className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-white/70 backdrop-blur-sm border-0 overflow-hidden">
                  <CardContent className="p-8 relative">
                    {/* Background gradient on hover */}
                    <div className={`absolute inset-0 bg-gradient-to-r ${info.bgColor} opacity-0 group-hover:opacity-50 transition-opacity duration-300`}></div>
                    
                    <a
                      href={info.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-6 group-hover:scale-105 transition-transform duration-300 relative z-10"
                    >
                      <div className={`w-16 h-16 bg-gradient-to-br ${info.color} rounded-2xl flex items-center justify-center shadow-lg group-hover:rotate-3 transition-transform duration-300`}>
                        <info.icon className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h4 className="text-xl font-bold text-gray-900 group-hover:text-portfolio-purple transition-colors duration-300">
                          {info.type}
                        </h4>
                        <p className="text-gray-600 group-hover:text-gray-700 transition-colors duration-300">{info.value}</p>
                      </div>
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
