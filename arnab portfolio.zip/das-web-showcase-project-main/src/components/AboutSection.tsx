
import { Card, CardContent } from '@/components/ui/card';
import { GraduationCap, Brain, Code } from 'lucide-react';

const AboutSection = () => {
  const education = [
    {
      degree: 'B.Tech in CSE (AI-ML)',
      institution: 'Brainware University',
      status: 'Ongoing, 2nd year student',
      color: 'from-portfolio-purple to-portfolio-blue',
      icon: GraduationCap,
      year: '2022-2026'
    },
    {
      degree: 'Higher Secondary',
      institution: 'Pathfinder Higher Secondary Public School (PHSPS), Jodhpur Park, Kolkata',
      status: 'Completed in 2021',
      color: 'from-portfolio-blue to-portfolio-orange',
      icon: Brain,
      year: '2021'
    },
    {
      degree: 'Madhyamik',
      institution: 'Chandpur Upendranath High School, Howrah',
      status: 'Completed in 2019',
      color: 'from-portfolio-orange to-portfolio-purple',
      icon: Code,
      year: '2019'
    }
  ];

  const stats = [
    { number: '2+', label: 'Years Learning', color: 'from-purple-500 to-blue-500' },
    { number: '5+', label: 'Technologies', color: 'from-blue-500 to-teal-500' },
    { number: '2+', label: 'Projects Built', color: 'from-teal-500 to-green-500' },
    { number: '100%', label: 'Dedication', color: 'from-green-500 to-purple-500' }
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-br from-white via-gray-50 to-blue-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-gradient-to-br from-portfolio-purple/5 to-portfolio-blue/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-portfolio-orange/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm mb-6">
            <span className="text-sm font-medium text-gray-700">Get to know me</span>
          </div>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            About <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple to-portfolio-blue">Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-portfolio-purple to-portfolio-orange mx-auto mb-8 rounded-full"></div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center p-6 bg-white/50 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-0">
                <div className={`text-3xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* About Text */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">
                Designing Solutions, Not Just Visuals
              </h3>
              <div className="space-y-4 text-lg text-gray-600 leading-relaxed">
                <p>
                  I am <span className="font-semibold text-portfolio-purple">Arnab Das</span>, currently pursuing a B.Tech in Computer Science and Engineering (AI & ML) at Brainware University, Kolkata. I'm passionate about building modern, responsive websites and currently working as a Full Stack Web Development Intern at Future Interns.
                </p>
                <p>
                  My journey in technology combines academic excellence with practical experience. I believe in creating digital solutions that not only look great but also provide exceptional user experiences and solve real-world problems.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-gradient-to-br from-portfolio-purple/10 to-portfolio-blue/10 text-portfolio-purple px-6 py-4 rounded-2xl text-center backdrop-blur-sm border border-portfolio-purple/20">
                <div className="text-2xl mb-2">🎯</div>
                <div className="text-sm font-semibold">Goal-Oriented</div>
              </div>
              <div className="bg-gradient-to-br from-portfolio-blue/10 to-portfolio-orange/10 text-portfolio-blue px-6 py-4 rounded-2xl text-center backdrop-blur-sm border border-portfolio-blue/20">
                <div className="text-2xl mb-2">💡</div>
                <div className="text-sm font-semibold">Creative Problem Solver</div>
              </div>
              <div className="bg-gradient-to-br from-portfolio-orange/10 to-portfolio-purple/10 text-portfolio-orange px-6 py-4 rounded-2xl text-center backdrop-blur-sm border border-portfolio-orange/20">
                <div className="text-2xl mb-2">🚀</div>
                <div className="text-sm font-semibold">Innovation Driven</div>
              </div>
            </div>
          </div>

          {/* Education Timeline */}
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 mb-8">Educational Journey</h3>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-white/70 backdrop-blur-sm border-0">
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 bg-gradient-to-r ${edu.color} rounded-xl flex items-center justify-center shadow-lg`}>
                        <edu.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-xl font-bold text-gray-900">{edu.degree}</h4>
                          <span className="text-sm font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">{edu.year}</span>
                        </div>
                        <p className="text-gray-600 mb-3 leading-relaxed">{edu.institution}</p>
                        <div className={`inline-flex items-center px-3 py-1 bg-gradient-to-r ${edu.color} text-white text-sm font-medium rounded-full`}>
                          {edu.status}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
