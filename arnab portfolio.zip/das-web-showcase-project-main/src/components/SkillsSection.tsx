
import { Card, CardContent } from '@/components/ui/card';
import { Code, Palette, Server, Smartphone, Database, Globe } from 'lucide-react';

const SkillsSection = () => {
  const skills = [
    { name: 'HTML', level: 90, color: 'from-orange-500 to-red-500', icon: '🌐' },
    { name: 'CSS', level: 85, color: 'from-blue-500 to-indigo-500', icon: '🎨' },
    { name: 'JavaScript', level: 80, color: 'from-yellow-400 to-orange-500', icon: '⚡' },
    { name: 'React', level: 75, color: 'from-cyan-400 to-blue-500', icon: '⚛️' },
    { name: 'Node.js', level: 70, color: 'from-green-400 to-emerald-500', icon: '🚀' },
  ];

  const additionalSkills = [
    { name: 'Full Stack Development', icon: Code, color: 'from-purple-500 to-blue-500' },
    { name: 'Responsive Design', icon: Smartphone, color: 'from-blue-500 to-teal-500' },
    { name: 'UI/UX Design', icon: Palette, color: 'from-pink-500 to-rose-500' },
    { name: 'Version Control (Git)', icon: Server, color: 'from-gray-600 to-gray-800' },
    { name: 'Problem Solving', icon: Database, color: 'from-indigo-500 to-purple-500' },
    { name: 'Team Collaboration', icon: Globe, color: 'from-green-500 to-teal-500' }
  ];

  return (
    <section id="skills" className="py-24 bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-portfolio-blue/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-br from-portfolio-orange/5 to-portfolio-purple/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm mb-6">
            <span className="text-sm font-medium text-gray-700">What I'm good at</span>
          </div>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple to-portfolio-blue">Skills</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-portfolio-purple to-portfolio-orange mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Expertise Services! Let's check it out
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Technical Skills */}
          <Card className="p-8 bg-white/70 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300">
            <CardContent className="p-0">
              <h3 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-portfolio-purple to-portfolio-blue rounded-xl flex items-center justify-center">
                  <Code className="w-5 h-5 text-white" />
                </div>
                Technical Expertise
              </h3>
              <div className="space-y-8">
                {skills.map((skill, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{skill.icon}</span>
                        <span className="text-lg font-semibold text-gray-700">{skill.name}</span>
                      </div>
                      <span className="text-sm font-bold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">{skill.level}%</span>
                    </div>
                    <div className="relative">
                      <div className="w-full bg-gray-200 rounded-full h-4 shadow-inner">
                        <div
                          className={`h-4 rounded-full bg-gradient-to-r ${skill.color} transition-all duration-1000 ease-out shadow-lg relative overflow-hidden`}
                          style={{ width: `${skill.level}%` }}
                        >
                          <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Additional Skills */}
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-portfolio-orange to-portfolio-purple rounded-xl flex items-center justify-center">
                <Palette className="w-5 h-5 text-white" />
              </div>
              Core Competencies
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {additionalSkills.map((skill, index) => (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white/70 backdrop-blur-sm border-0 overflow-hidden">
                  <CardContent className="p-6 text-center relative">
                    <div className={`w-16 h-16 bg-gradient-to-r ${skill.color} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <skill.icon className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="text-lg font-bold text-gray-900 group-hover:text-portfolio-purple transition-colors duration-300">{skill.name}</h4>
                    
                    {/* Hover effect overlay */}
                    <div className={`absolute inset-0 bg-gradient-to-r ${skill.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300 rounded-lg`}></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
