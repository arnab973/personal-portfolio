import { Button } from '@/components/ui/button';
const HeroSection = () => {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };
  return <section id="home" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 overflow-hidden">
      {/* Modern background patterns */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Mzk3ZGQiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE0YzIuMiAwIDQgMS44IDQgNHMtMS44IDQtNCA0LTQtMS44LTQtNCAxLjgtNCA0LTR6bTAgMzJjMi4yIDAgNCAxLjggNCA0cy0xLjggNC00IDQtNC0xLjgtNC00IDEuOC00IDQtNHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30 bg-indigo-100"></div>
      
      {/* Floating elements with modern glassmorphism */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-br from-portfolio-purple/20 to-portfolio-blue/20 rounded-2xl backdrop-blur-sm animate-float"></div>
      <div className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-br from-portfolio-orange/20 to-portfolio-purple/20 rounded-full backdrop-blur-sm animate-float" style={{
      animationDelay: '1s'
    }}></div>
      <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-br from-portfolio-blue/20 to-portfolio-orange/20 rounded-3xl backdrop-blur-sm animate-float" style={{
      animationDelay: '2s'
    }}></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content with enhanced typography */}
          <div className="text-center lg:text-left animate-fade-in space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 shadow-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                <span className="text-sm font-medium text-gray-700">Available for work</span>
              </div>
              
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 leading-tight">
                Hello, I'm{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-portfolio-purple via-portfolio-blue to-portfolio-orange animate-gradient">
                  Arnab Das
                </span>
              </h1>
              
              <div className="space-y-4">
                <p className="text-xl sm:text-2xl text-gray-600 leading-relaxed">
                  Aspiring Full Stack Developer | AI-ML Enthusiast
                </p>
                <p className="text-lg text-portfolio-purple font-semibold">
                  Crafting the Web, One Line at a Time
                </p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button onClick={scrollToContact} className="group bg-gradient-to-r from-portfolio-purple to-portfolio-blue hover:from-portfolio-purple/90 hover:to-portfolio-blue/90 text-white px-8 py-4 text-lg font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl shadow-lg">
                <span className="mr-2">Get In Touch</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </Button>
              <Button variant="outline" className="border-2 border-gray-300 bg-white/50 backdrop-blur-sm text-gray-700 hover:bg-white hover:text-portfolio-purple hover:border-portfolio-purple px-8 py-4 text-lg font-semibold rounded-2xl transition-all duration-300 hover:shadow-lg">
                View My Work
              </Button>
            </div>
          </div>

          {/* Right Content - Enhanced Profile Image */}
          <div className="flex justify-center lg:justify-end animate-slide-in-right">
            <div className="relative">
              {/* Modern gradient rings */}
              <div className="absolute inset-0 bg-gradient-to-r from-portfolio-purple via-portfolio-blue to-portfolio-orange rounded-full animate-spin-slow"></div>
              <div className="relative w-80 h-80 lg:w-96 lg:h-96 rounded-full bg-white p-2">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-gray-50 to-white p-4 shadow-2xl">
                  <div className="w-full h-full rounded-full overflow-hidden bg-gradient-to-br from-portfolio-blue/10 to-portfolio-purple/10">
                    <img src="https://i.postimg.cc/fy5G9BF2/Whats-App-Image-2025-06-22-at-22-05-31-7a95192f.jpg" alt="Arnab Das - Full Stack Developer" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                  </div>
                </div>
              </div>
              
              {/* Modern floating badges */}
              <div className="absolute -top-4 -right-4 bg-gradient-to-r from-portfolio-orange to-portfolio-purple text-white px-6 py-3 rounded-2xl text-sm font-bold shadow-lg animate-bounce-gentle backdrop-blur-sm">
                B.Tech CSE
              </div>
              <div className="absolute -bottom-4 -left-4 bg-gradient-to-r from-portfolio-blue to-portfolio-purple text-white px-6 py-3 rounded-2xl text-sm font-bold shadow-lg animate-bounce-gentle backdrop-blur-sm" style={{
              animationDelay: '1s'
            }}>
                AI-ML
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default HeroSection;